# Speech and facial emotion recognition: evaluation-protocol sensitivity and a Relief ablation

Code and results for the manuscript **"Benchmarking Pretrained-Feature Pipelines for Speech and Facial Emotion Recognition: Evaluation-Protocol Sensitivity and a Relief Ablation"** (submitted to *Informatics*, MDPI).

Every number in the paper can be regenerated from these scripts. All feature extractors are frozen, publicly available pretrained models; classifiers are scikit-learn models (one-hidden-layer perceptron, linear probes, classical baselines). There is no fusion, EEG or real-time component.

## Headline results (mean ± SD over 5 seeds; full tables in `results/`)
| Experiment | Result |
|---|---|
| Speech, protocol A (unseen speakers), wav2vec 2.0 + handcrafted, MLP | 59.3 ± 1.7 % |
| Speech, protocol C (random split, augmentation after split; speakers overlap) | 64.4 ± 1.7 % |
| Speech, protocol B (augmentation before split; speakers overlap + leakage) | 68.7 ± 1.1 % |
| Speech, linear probe, protocol A: wav2vec 2.0 / HuBERT / WavLM | 59.8 / 65.6 / 67.1 % |
| Speech, Relief top-K (K = 50 … 908) and Relief scores as feature scaling | 42.7 … 58.9 %; 59.5 ± 1.9 % |
| Faces (FER-2013 private test), dual ImageNet backbone MLP | 61.0 ± 0.7 % |
| Faces, CLIP ViT-B/32 MLP / ViT-B/16 MLP | 67.7 ± 0.5 % / 62.8 ± 0.5 % |

## Data (public; not redistributed)
See `data/README.md`. Models: `facebook/wav2vec2-base`, `microsoft/wavlm-base-plus`, `facebook/hubert-base-ls960`, `google/vit-base-patch16-224-in21k`, `openai/clip-vit-base-patch32` (Hugging Face); torchvision ImageNet weights for ResNet-152 and EfficientNet-B7. TESS was not used; RAVDESS "calm" dropped; 7 classes.

## Run (Python 3.12; about 40 min for steps 01–07 on an Apple M1 Pro, plus about 35 min for step 09)
```
pip install -r requirements.txt
python scripts/01_extract_features.py              # speech features (handcrafted + wav2vec 2.0), original + one augmented copy per clip
python scripts/02_run_experiments.py               # protocols A and B, ablation, baselines, 5 seeds
python scripts/03_make_figures.py
python scripts/04_extract_face.py                  # ResNet-152, EfficientNet-B7, HOG features
python scripts/05_run_face.py                      # backbone ablation, ReliefF, baselines, 5 seeds
python scripts/06_make_face_fig.py
python scripts/07_make_paper_figures.py
python scripts/08_extra_protocol_and_k_sweep.py    # protocol C and the Relief K sweep / scaling variant
python scripts/09_extra_encoders.py speech         # WavLM and HuBERT probes (protocol A)
python scripts/09_extra_encoders.py face           # ViT-B/16 and CLIP ViT-B/32 (FER-2013)
```
Step 09 regenerates the augmented clips with the same seeded generator as step 01 and checks that the clip order is identical before running.

## Protocols
- **A (speaker-independent):** about 20 % of the speakers of each corpus held out for testing (24 speakers per seed); augmentation only for training speakers; test = original clips of held-out speakers.
- **C:** stratified random 80/20 split of the original clips (speakers overlap); augmentation only for training clips afterwards.
- **B (leaky):** augment first, then stratified random 80/20 split.
- **Facial:** standard FER-2013 split; private test = test, public test = validation; no selection on test data.
- **ReliefF:** own multi-class implementation (k = 10 neighbours per class, class-prior weighting), used for top-K selection or as feature scaling. It is ReliefF, not Iterative Relief.

## Results (`results/`)
| File | Content |
|---|---|
| `summary.csv`, `per_seed_results.csv` | speech, protocols A and B |
| `extra_summary.csv`, `extra_per_seed.csv` | protocol C and Relief K sweep |
| `extra_encoders_speech_*.csv`, `extra_encoders_face_*.csv` | other frozen encoders |
| `face_summary.csv`, `face_per_seed_results.csv` | facial results |
| `split_seed*.json` | held-out speaker IDs for each seed |
| `confusion_*.csv`, `face_confusion_*.csv` | confusion matrices summed over seeds |
| `*_log.txt`, `*environment.json` | run logs and software versions |
| `figures/` | figures used in the paper |

Large feature files (`features*.npz`) are not included; regenerate them with steps 01 and 04.

## Licence and citation
MIT licence (`LICENSE`). Please cite the paper (`CITATION.cff`; the DOI of this repository will be added after the archive release).
