"""Step 1: load speech corpora, build 2.5 s clips, extract features.

Corpora: RAVDESS (speech), CREMA-D, SAVEE (+ TESS if present in data/tess).
Classes (7): angry, disgust, fear, happy, neutral, sad, surprise. RAVDESS 'calm' is dropped.
Features:
  hand = MFCC(30) mean+std, ZCR, RMS, chroma(12), log-Mel(64) mean  -> 140-d
  w2v  = facebook/wav2vec2-base, mean-pooled last hidden state      -> 768-d (pretrained, not fine-tuned)
For every clip one augmented copy is also built (random time shift + Gaussian noise, seeded).
Nothing is split here; splitting happens in step 2.
"""
import glob, io, os, re, sys, zipfile, time
import numpy as np, soundfile as sf, librosa, torch, pyarrow.parquet as pq
from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2Model

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA, RES = f'{ROOT}/data', f'{ROOT}/results'
SR, DUR = 16000, 2.5
N = int(SR * DUR)
CLASSES = ['angry', 'disgust', 'fear', 'happy', 'neutral', 'sad', 'surprise']
LIMIT = int(os.environ.get('LIMIT', 0))  # smoke-test: only first LIMIT clips per corpus

def fix_len(y):
    return np.pad(y, (0, N - len(y))) if len(y) < N else y[:N]

def to16k(y, sr):
    y = y.astype(np.float32)
    if y.ndim > 1: y = y.mean(1)
    return librosa.resample(y, orig_sr=sr, target_sr=SR) if sr != SR else y

clips = []  # (corpus, speaker, label, waveform)

def load_ravdess():
    """RAVDESS speech (1,440 clips, 24 actors) from the Hugging Face mirror xbgoose/ravdess."""
    if os.environ.get('SKIP_RAVDESS'): return  # smoke-test only
    files = sorted(glob.glob(f'{DATA}/ravdess/*.parquet'))
    if not files: raise SystemExit('RAVDESS parquet files missing')
    code = {'neutral': 'neutral', 'happy': 'happy', 'sad': 'sad', 'angry': 'angry', 'fearful': 'fear', 'disgust': 'disgust', 'surprised': 'surprise'}
    n = 0
    for f in files:
        for r in pq.read_table(f, columns=['audio', 'emotion', 'actor']).to_pylist():
            if LIMIT and n >= LIMIT: return
            lab = code.get(r['emotion'])  # 'calm' is dropped
            if lab is None: continue
            y, sr = sf.read(io.BytesIO(r['audio']['bytes']))
            clips.append(('ravdess', f"ravdess_{r['actor']}", lab, fix_len(to16k(y, sr)))); n += 1

def load_parquet(corpus, files, labelmap, spk):
    for f in files:
        t = pq.read_table(f, columns=['file', 'audio', 'emotion']).to_pylist()
        if LIMIT: t = t[:LIMIT]
        for r in t:
            lab = labelmap.get(r['emotion'])
            if lab is None: continue
            y, sr = sf.read(io.BytesIO(r['audio']['bytes']))
            clips.append((corpus, f'{corpus}_' + spk(os.path.basename(r['file'])), lab, fix_len(to16k(y, sr))))

def load_all():
    load_ravdess()
    load_parquet('cremad', sorted(glob.glob(f'{DATA}/cremad/*.parquet')),
                 {'anger': 'angry', 'disgust': 'disgust', 'fear': 'fear', 'happy': 'happy', 'neutral': 'neutral', 'sad': 'sad'},
                 lambda b: b.split('_')[0])
    load_parquet('savee', sorted(glob.glob(f'{DATA}/savee/*.parquet')),
                 {'anger': 'angry', 'disgust': 'disgust', 'fear': 'fear', 'happiness': 'happy', 'neutral': 'neutral', 'sadness': 'sad', 'surprise': 'surprise'},
                 lambda b: b.split('_')[0])

def augment(y, rng):
    y = np.roll(y, int(rng.uniform(-0.2, 0.2) * SR))
    noise = rng.normal(0, 1, len(y)).astype(np.float32)
    snr = rng.uniform(15, 30)
    sp, npw = np.mean(y ** 2) + 1e-9, np.mean(noise ** 2)
    return y + noise * np.sqrt(sp / (npw * 10 ** (snr / 10)))

def handcrafted(y):
    mf = librosa.feature.mfcc(y=y, sr=SR, n_mfcc=30)
    mel = librosa.power_to_db(librosa.feature.melspectrogram(y=y, sr=SR, n_mels=64))
    ch = librosa.feature.chroma_stft(y=y, sr=SR)
    zc = librosa.feature.zero_crossing_rate(y); rm = librosa.feature.rms(y=y)
    return np.concatenate([mf.mean(1), mf.std(1), [zc.mean(), zc.std(), rm.mean(), rm.std()], ch.mean(1), mel.mean(1)]).astype(np.float32)

def main():
    t0 = time.time(); load_all()
    print('clips', len(clips), {c: sum(1 for x in clips if x[0] == c) for c in {x[0] for x in clips}}, flush=True)
    rng = np.random.default_rng(0)
    waves = [c[3] for c in clips]
    augs = [augment(w, rng) for w in waves]
    dev = 'mps' if torch.backends.mps.is_available() else 'cpu'
    fe = Wav2Vec2FeatureExtractor.from_pretrained('facebook/wav2vec2-base')
    m = Wav2Vec2Model.from_pretrained('facebook/wav2vec2-base').to(dev).eval()
    def w2v(ws, bs=32):
        out = []
        with torch.no_grad():
            for i in range(0, len(ws), bs):
                inp = fe([w for w in ws[i:i + bs]], sampling_rate=SR, return_tensors='pt', padding=False)
                out.append(m(inp.input_values.to(dev)).last_hidden_state.mean(1).cpu().numpy())
                if (i // bs) % 20 == 0: print(f'  w2v {i}/{len(ws)}  {time.time() - t0:.0f}s', flush=True)
        return np.concatenate(out)
    X_w = np.concatenate([w2v(waves), w2v(augs)])
    X_h = np.stack([handcrafted(w) for w in waves + augs])
    n = len(clips)
    np.savez_compressed(f'{RES}/features{"_smoke" if LIMIT else ""}.npz',
        X_hand=X_h, X_w2v=X_w, y=np.array([CLASSES.index(c[2]) for c in clips] * 2),
        speaker=np.array([c[1] for c in clips] * 2), corpus=np.array([c[0] for c in clips] * 2),
        is_aug=np.array([0] * n + [1] * n), orig_idx=np.array(list(range(n)) * 2), classes=np.array(CLASSES))
    print('saved', X_h.shape, X_w.shape, f'{time.time() - t0:.0f}s')

if __name__ == '__main__':
    main()
