"""Facial figure: train vs test accuracy per configuration (from results/face_summary.csv)."""
import os, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Patch
R = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'results')
plt.rcParams.update({'font.family': 'DejaVu Serif', 'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
s = pd.read_csv(f'{R}/face_summary.csv').set_index('config')
order = ['EfficientNet-B7 only (MLP)', 'ResNet-152 only (MLP)', 'Dual backbone (MLP)', 'Dual backbone + ReliefF (MLP)', 'Logistic regression, dual backbone [baseline]', 'HOG + linear SVM [baseline]']
lab = ['EfficientNet-B7 only', 'ResNet-152 only', 'Dual backbone', 'Dual backbone + ReliefF', 'Logistic reg. (dual backbone)', 'HOG + linear SVM']
fig, ax = plt.subplots(figsize=(7.2, 4.2)); y = np.arange(len(order))[::-1]
for i, c in enumerate(order):
    tr, te, sd = 100 * s.loc[c, 'train_mean'], 100 * s.loc[c, 'test_mean'], 100 * (s.loc[c, 'test_sd'] if s.loc[c, 'n_runs'] > 1 else 0)
    ax.barh(y[i] + 0.19, tr, 0.36, color='#b9c4d6'); ax.text(tr + 0.8, y[i] + 0.19, f'{tr:.1f}', va='center', fontsize=8.5)
    ax.barh(y[i] - 0.19, te, 0.36, xerr=sd or None, color='#1f4e8c', capsize=2, error_kw={'lw': 1}); ax.text(te + sd + 0.8, y[i] - 0.19, f'{te:.1f}', va='center', fontsize=8.5)
ax.set_yticks(y); ax.set_yticklabels(lab); ax.set_xlim(0, 105); ax.set_xlabel('Accuracy (%), FER-2013; mean ± SD over 5 seeds')
ax.legend(handles=[Patch(color='#b9c4d6', label='Training accuracy'), Patch(color='#1f4e8c', label='Test accuracy')], loc='upper center', bbox_to_anchor=(0.45, 1.12), ncol=2, frameon=False, fontsize=8.5)
plt.tight_layout(); plt.savefig(f'{R}/figures/fig_face_ablation.png', dpi=250); print('ok')
