"""Step 9 (revision round 2): linear probes / perceptrons on other frozen encoders under the SAME splits and seeds.
Speech (protocol A): WavLM-base-plus, HuBERT-base (mean-pooled last hidden state, 768-d), compared with wav2vec 2.0 base.
Face (standard FER-2013 split): ViT-B/16 (ImageNet-21k, CLS token 768-d) and CLIP ViT-B/32 image embedding (512-d).
Augmented waveforms are regenerated with the same seeded generator as step 1 (identical clips).
Usage: python 09_extra_encoders.py speech|face
"""
import importlib.util, io, os, sys, time, numpy as np, pandas as pd, torch, pyarrow.parquet as pq
from PIL import Image
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score
here = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(here); RES = f'{ROOT}/results'
dev = 'mps' if torch.backends.mps.is_available() else 'cpu'; t0 = time.time()
def P(*a):
    s = ' '.join(map(str, a)); print(s, flush=True); open(f'{RES}/extra_encoders_log.txt', 'a').write(s + '\n')

def speech():
    from transformers import AutoFeatureExtractor, AutoModel
    sp = importlib.util.spec_from_file_location('s1', f'{here}/01_extract_features.py'); S1 = importlib.util.module_from_spec(sp); sys.modules['s1'] = sp.loader.exec_module(S1) or S1
    S1.load_all(); waves = [c[3] for c in S1.clips]; rng = np.random.default_rng(0); augs = [S1.augment(w, rng) for w in waves]
    ref = np.load(f'{RES}/features.npz', allow_pickle=True)
    assert len(waves) * 2 == len(ref['y']) and (np.array([S1.CLASSES.index(c[2]) for c in S1.clips] * 2) == ref['y']).all(), 'clip order mismatch'
    feats = {}
    for name, hub in [('WavLM-base-plus', 'microsoft/wavlm-base-plus'), ('HuBERT-base', 'facebook/hubert-base-ls960')]:
        fe = AutoFeatureExtractor.from_pretrained(hub); m = AutoModel.from_pretrained(hub).to(dev).eval(); out = []
        allw = waves + augs
        with torch.no_grad():
            for i in range(0, len(allw), 32):
                inp = fe(allw[i:i + 32], sampling_rate=16000, return_tensors='pt'); out.append(m(inp.input_values.to(dev)).last_hidden_state.mean(1).cpu().numpy())
                if (i // 32) % 50 == 0: P(f'  {name} {i}/{len(allw)} {time.time() - t0:.0f}s')
        feats[name] = np.concatenate(out); np.savez_compressed(f'{RES}/features_extra_speech_{name}.npz', X=feats[name])
        del m
    feats['Wav2Vec 2.0 base (reference)'] = ref['X_w2v']
    spec = importlib.util.spec_from_file_location('e02', f'{here}/02_run_experiments.py'); E = importlib.util.module_from_spec(spec); sys.modules['e02'] = E; spec.loader.exec_module(E)
    rows = []
    for seed in E.SEEDS:
        ts = E.split_speakers(seed); te = np.isin(E.spk, list(ts)) & (E.aug == 0); tr = ~np.isin(E.spk, list(ts))
        for name, X in feats.items():
            sc = StandardScaler().fit(X[tr]); A, B = sc.transform(X[tr]), sc.transform(X[te])
            for cn, mdl in [('linear probe (LogReg)', LogisticRegression(max_iter=2000, random_state=seed)), ('MLP', MLPClassifier((256,), early_stopping=True, max_iter=300, random_state=seed))]:
                pr = mdl.fit(A, E.y[tr]).predict(B)
                rows.append(dict(encoder=name, classifier=cn, seed=seed, acc=accuracy_score(E.y[te], pr), macro_f1=f1_score(E.y[te], pr, average='macro'))); P(f'[seed {seed}] {name} {cn} acc {rows[-1]["acc"]:.4f}')
    df = pd.DataFrame(rows); df.to_csv(f'{RES}/extra_encoders_speech_per_seed.csv', index=False)
    sm = df.groupby(['encoder', 'classifier']).agg(acc_mean=('acc', 'mean'), acc_sd=('acc', 'std'), f1_mean=('macro_f1', 'mean'), f1_sd=('macro_f1', 'std')).reset_index()
    sm.to_csv(f'{RES}/extra_encoders_speech_summary.csv', index=False); P(sm.round(4).to_string(index=False))

def face():
    from transformers import ViTModel, CLIPModel
    def load(split):
        t = pq.read_table(f'{ROOT}/data/fer/{split}.parquet').to_pylist()
        return np.stack([np.array(Image.open(io.BytesIO(r['image']['bytes'])).convert('L')) for r in t]), np.array([r['label'] for r in t])
    data = {s: load(s) for s in ['train', 'publicTest', 'privateTest']}
    vit = ViTModel.from_pretrained('google/vit-base-patch16-224-in21k').to(dev).eval(); clip = CLIPModel.from_pretrained('openai/clip-vit-base-patch32').to(dev).eval()
    m1 = torch.tensor([0.5] * 3, device=dev).view(1, 3, 1, 1); s1 = m1.clone()
    m2 = torch.tensor([0.4815, 0.4578, 0.4082], device=dev).view(1, 3, 1, 1); s2 = torch.tensor([0.2686, 0.2613, 0.2758], device=dev).view(1, 3, 1, 1)
    F = {}
    for s, (X, y) in data.items():
        o1, o2 = [], []
        with torch.no_grad():
            for i in range(0, len(X), 64):
                x = torch.nn.functional.interpolate(torch.from_numpy(X[i:i + 64]).float().div(255).to(dev).unsqueeze(1).repeat(1, 3, 1, 1), size=224, mode='bilinear', align_corners=False)
                o1.append(vit(pixel_values=(x - m1) / s1).last_hidden_state[:, 0].cpu().numpy()); o2.append(clip.get_image_features(pixel_values=(x - m2) / s2).cpu().numpy() if not hasattr(clip.get_image_features(pixel_values=(x - m2) / s2), 'pooler_output') else clip.get_image_features(pixel_values=(x - m2) / s2).pooler_output.cpu().numpy())
                if (i // 64) % 100 == 0: P(f'  face {s} {i}/{len(X)} {time.time() - t0:.0f}s')
        F[s] = (np.concatenate(o1), np.concatenate(o2), y)
    np.savez_compressed(f'{RES}/features_extra_face.npz', **{f'{s}_{k}': F[s][j] for s in F for j, k in enumerate(['vit', 'clip', 'y'])})
    rows = []
    for seed in range(5):
        for name, j in [('ViT-B/16 (IN-21k)', 0), ('CLIP ViT-B/32', 1)]:
            sc = StandardScaler().fit(F['train'][j]); A, B = sc.transform(F['train'][j]), sc.transform(F['privateTest'][j]); ytr, yte = F['train'][2], F['privateTest'][2]
            for cn, mdl in [('linear probe (LogReg)', LogisticRegression(max_iter=500, random_state=seed)), ('MLP', MLPClassifier((256,), early_stopping=True, validation_fraction=0.1, max_iter=200, random_state=seed, alpha=1e-3))]:
                if cn.startswith('linear') and seed > 0: continue
                pr = mdl.fit(A, ytr).predict(B); rows.append(dict(encoder=name, classifier=cn, seed=seed, test_acc=accuracy_score(yte, pr), test_macro_f1=f1_score(yte, pr, average='macro'))); P(f'[seed {seed}] {name} {cn} test {rows[-1]["test_acc"]:.4f}')
    df = pd.DataFrame(rows); df.to_csv(f'{RES}/extra_encoders_face_per_seed.csv', index=False)
    sm = df.groupby(['encoder', 'classifier']).agg(n=('seed', 'count'), acc_mean=('test_acc', 'mean'), acc_sd=('test_acc', 'std'), f1_mean=('test_macro_f1', 'mean')).reset_index()
    sm.to_csv(f'{RES}/extra_encoders_face_summary.csv', index=False); P(sm.round(4).to_string(index=False))
{'speech': speech, 'face': face}[sys.argv[1]]()
