"""Step 8 (added for revision round 2): separates the two confounded effects of protocol B and sweeps Relief K.

Protocol C: stratified random 80/20 split of the ORIGINAL clips (speakers overlap), augmented copies made only
            for training clips afterwards; test = originals only. => speaker overlap WITHOUT augmentation leakage.
            Compare: A -> C isolates speaker overlap; C -> B isolates augmentation leakage.
Relief K sweep (protocol A, combined features, MLP): K in 50/100/300/600, plus weights used as feature scaling.
Writes only new files (extra_*.csv, extra_log.txt); does not touch earlier results.
"""
import importlib.util, os, sys, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score
here = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('exp02', f'{here}/02_run_experiments.py'); E = importlib.util.module_from_spec(spec)
sys.modules['exp02'] = E; spec.loader.exec_module(E)
RES = E.RES; log = open(f'{RES}/extra_log.txt', 'a')
def P(*a):
    s = ' '.join(map(str, a)); print(s, flush=True); log.write(s + '\n'); log.flush()
y, spk, cor, aug, oid, Xh, Xw, Xc = E.y, E.spk, E.cor, E.aug, E.oid, E.Xh, E.Xw, E.Xc
rows = []
def mlp(A, ytr, B, yte, seed):
    m = E.MLPClassifier((256,), early_stopping=True, max_iter=300, random_state=seed).fit(A, ytr); pr = m.predict(B)
    return accuracy_score(yte, pr), f1_score(yte, pr, average='macro')
orig = np.where(aug == 0)[0]
for seed in E.SEEDS:
    # ---- Protocol C ----
    tr_o, te_o = train_test_split(orig, test_size=0.2, stratify=y[orig], random_state=seed)
    tr_mask = np.isin(oid, oid[tr_o])            # originals + augmented siblings of TRAIN originals only
    te_idx = te_o
    for name, X in [('Handcrafted only (MLP)', Xh), ('Wav2Vec 2.0 only (MLP)', Xw), ('Combined (MLP)', Xc)]:
        sc = StandardScaler().fit(X[tr_mask]); a, f = mlp(sc.transform(X[tr_mask]), y[tr_mask], sc.transform(X[te_idx]), y[te_idx], seed)
        rows.append(dict(experiment='C random split of originals, aug after split', config=name, seed=seed, acc=a, macro_f1=f))
        P(f'[seed {seed}] C {name:28s} acc {a:.4f}')
    # ---- Relief K sweep, protocol A ----
    test_spk = E.split_speakers(seed); te = np.isin(spk, list(test_spk)) & (aug == 0); tr = ~np.isin(spk, list(test_spk))
    Xtr, Xte = Xc[tr], Xc[te]; sc = StandardScaler().fit(Xtr); A, B = sc.transform(Xtr), sc.transform(Xte)
    lo, hi = Xtr.min(0), Xtr.max(0); S = ((Xtr - lo) / np.maximum(hi - lo, 1e-9)).astype(np.float32)
    w = E.relieff(S, y[tr], oid[tr], E.M_RELIEF, E.K_NEIGH, seed)
    order = np.argsort(-w)
    for K in [50, 100, 300, 600, 908]:
        sel = order[:K]; a, f = mlp(A[:, sel], y[tr], B[:, sel], y[te], seed)
        rows.append(dict(experiment='Relief top-K (protocol A)', config=f'K={K}', seed=seed, acc=a, macro_f1=f)); P(f'[seed {seed}] K={K} acc {a:.4f}')
    ws = np.clip(w, 0, None); ws = ws / ws.max()
    a, f = mlp(A * ws, y[tr], B * ws, y[te], seed)
    rows.append(dict(experiment='Relief top-K (protocol A)', config='weights as feature scaling (all 908)', seed=seed, acc=a, macro_f1=f)); P(f'[seed {seed}] scaling acc {a:.4f}')
    pd.DataFrame(rows).to_csv(f'{RES}/extra_per_seed.csv', index=False)
df = pd.DataFrame(rows)
sm = df.groupby(['experiment', 'config'], sort=False).agg(acc_mean=('acc', 'mean'), acc_sd=('acc', 'std'), f1_mean=('macro_f1', 'mean'), f1_sd=('macro_f1', 'std')).reset_index()
sm.to_csv(f'{RES}/extra_summary.csv', index=False); P(sm.round(4).to_string(index=False))
