"""Replacement figures for the revised manuscript.
Fig 17: per-class precision/recall/F1 from the paper's own Table 4, with the overall-accuracy line at the value implied by Figure 20 (9374/9730 = 0.9634).
Fig 19: log-Mel spectrograms of ONE RAVDESS sentence spoken by one actor in three emotions (real data from data/ravdess)."""
import glob, io, os, numpy as np, pyarrow.parquet as pq, soundfile as sf, librosa, librosa.display, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); OUT = f'{ROOT}/results/figures'
# ---- Figure 17
cls = ['Angry', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', 'Surprise']
P = [.96, .97, .96, .96, .97, .96, .98]; R = [.97, .95, .97, .95, .98, .97, .97]; F = [.97, .96, .96, .96, .97, .96, .97]; ACC = 9374 / 9730
fig, ax = plt.subplots(figsize=(7.2, 4.77)); plt.rcParams.update({'font.size': 10})
ax.plot(cls, P, 'o-', color='#1f77b4', label='Precision'); ax.plot(cls, R, 's--', color='#ff7f0e', label='Recall'); ax.plot(cls, F, 'D-.', color='#2ca02c', label='F1-score')
ax.axhline(ACC, color='#d62728', ls=':', lw=1.8, label=f'Overall accuracy ({ACC:.4f})')
ax.set_ylim(0.90, 1.05); ax.set_ylabel('Score'); ax.set_xlabel('Emotion'); ax.set_title('Per-class precision, recall and F1-score (Table 4)', fontweight='bold')
ax.grid(True, color='#ddd'); ax.legend(loc='upper right', fontsize=8.5, ncol=2); plt.tight_layout(); plt.savefig(f'{OUT}/paper_fig17.png', dpi=200); plt.close()
# ---- Figure 19
rows = []
for f in sorted(glob.glob(f'{ROOT}/data/ravdess/*.parquet')):
    rows += pq.read_table(f, columns=['audio', 'emotion', 'emotional_intensity', 'statement', 'repetition', 'actor', 'vocal_channel']).to_pylist()
cand = {}
for r in rows:
    if r['vocal_channel'] == 'speech' and r['emotional_intensity'] == 'normal' and r['repetition'] == '1st repetition':
        cand.setdefault((r['actor'], r['statement']), {})[r['emotion']] = r
key = next(k for k, v in sorted(cand.items()) if {'neutral', 'angry', 'sad'} <= set(v))
fig, axs = plt.subplots(1, 3, figsize=(7.2, 4.77), sharey=True, constrained_layout=True)
W = {}
for emo in ['neutral', 'angry', 'sad']:
    y, sr = sf.read(io.BytesIO(cand[key][emo]['audio']['bytes'])); y = librosa.resample(y.astype(np.float32), orig_sr=sr, target_sr=22050)
    W[emo] = librosa.effects.trim(y, top_db=30)[0]
L = min(len(v) for v in W.values())  # same duration in all panels
for ax, emo in zip(axs, ['neutral', 'angry', 'sad']):
    S = librosa.power_to_db(librosa.feature.melspectrogram(y=W[emo][:L], sr=22050, n_fft=2048, hop_length=512, n_mels=128), ref=np.max)
    im = librosa.display.specshow(S, sr=22050, hop_length=512, x_axis='time', y_axis='mel', ax=ax, vmin=-80, vmax=0, cmap='magma'); ax.set_title(emo.capitalize(), fontsize=10)
    ax.set_xticks([0, 0.5, 1.0]); 
    if ax is not axs[0]: ax.set_ylabel('')
fig.colorbar(im, ax=axs, format='%+2.0f dB', fraction=0.04, pad=0.02)
fig.suptitle(f'RAVDESS actor {key[0]}: "{key[1]}"', fontsize=10); plt.savefig(f'{OUT}/paper_fig19.png', dpi=200); print('ok', key)
