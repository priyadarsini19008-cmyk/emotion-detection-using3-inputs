"""Facial step 1: FER-2013 (standard train / publicTest / privateTest split) -> frozen ImageNet-pretrained backbone features.
ResNet-152 (2048-d) and EfficientNet-B7 (2560-d), torchvision weights, 224x224 input (as in the paper's Section 2.3.2), no fine-tuning.
Also HOG features (classical baseline). Output: results/face_features.npz"""
import io, os, time, numpy as np, pyarrow.parquet as pq, torch, torch.nn.functional as F
from PIL import Image
from torchvision import models
from skimage.feature import hog
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); LIMIT = int(os.environ.get('LIMIT', 0))
NAMES = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
def load(split):
    t = pq.read_table(f'{ROOT}/data/fer/{split}.parquet').to_pylist()
    if LIMIT: t = t[:LIMIT]
    X = np.stack([np.array(Image.open(io.BytesIO(r['image']['bytes'])).convert('L')) for r in t]); return X, np.array([r['label'] for r in t])
dev = 'mps' if torch.backends.mps.is_available() else 'cpu'
r152 = models.resnet152(weights=models.ResNet152_Weights.IMAGENET1K_V1); r152.fc = torch.nn.Identity(); r152 = r152.to(dev).eval()
b7 = models.efficientnet_b7(weights=models.EfficientNet_B7_Weights.IMAGENET1K_V1); b7.classifier = torch.nn.Identity(); b7 = b7.to(dev).eval()
mean = torch.tensor([0.485, 0.456, 0.406], device=dev).view(1, 3, 1, 1); std = torch.tensor([0.229, 0.224, 0.225], device=dev).view(1, 3, 1, 1)
def feats(X, bs=64):
    o1, o2 = [], []; t0 = time.time()
    with torch.no_grad():
        for i in range(0, len(X), bs):
            x = torch.from_numpy(X[i:i + bs]).float().div(255).to(dev).unsqueeze(1).repeat(1, 3, 1, 1)
            x = (F.interpolate(x, size=224, mode='bilinear', align_corners=False) - mean) / std
            o1.append(r152(x).cpu().numpy()); o2.append(b7(x).cpu().numpy())
            if (i // bs) % 50 == 0: print(f'   {i}/{len(X)}  {time.time() - t0:.0f}s', flush=True)
    return np.concatenate(o1), np.concatenate(o2)
out = {}
for s in ['train', 'publicTest', 'privateTest']:
    print(s, flush=True); X, y = load(s); a, b = feats(X)
    out[f'{s}_r152'], out[f'{s}_b7'], out[f'{s}_y'] = a, b, y
    out[f'{s}_hog'] = np.stack([hog(im, orientations=9, pixels_per_cell=(6, 6), cells_per_block=(2, 2)) for im in X]).astype(np.float32)
np.savez_compressed(f'{ROOT}/results/face_features{"_smoke" if LIMIT else ""}.npz', classes=np.array(NAMES), **out); print('saved')
