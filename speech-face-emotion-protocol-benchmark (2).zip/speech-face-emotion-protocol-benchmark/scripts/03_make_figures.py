"""Step 3: figures for the paper, drawn only from results/summary.csv and the saved confusion matrix."""
import os, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); R = f'{ROOT}/results'
plt.rcParams.update({'font.family': 'DejaVu Serif', 'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
sm = pd.read_csv(f'{R}/summary.csv'); A = sm[sm.protocol.str.startswith('A')].set_index('config'); B = sm[sm.protocol.str.startswith('B')].set_index('config')
order = ['Handcrafted only (MLP)', 'Wav2Vec 2.0 only (MLP)', 'Combined (MLP)', 'Combined + ReliefF (MLP)',
         'SVM-RBF on handcrafted [baseline]', 'RandomForest on handcrafted [baseline]', 'LogReg on Wav2Vec 2.0 [baseline]']
lab = ['Handcrafted only', 'Wav2Vec 2.0 only', 'Combined', 'Combined + ReliefF', 'SVM (handcrafted)', 'Random forest (handcrafted)', 'Logistic reg. (Wav2Vec 2.0)']
fig, ax = plt.subplots(figsize=(7.2, 4.4)); y = np.arange(len(order))[::-1]
for i, c in enumerate(order):
    a = 100 * A.loc[c, 'acc_mean']; s = 100 * A.loc[c, 'acc_sd']
    ax.barh(y[i] + 0.19, a, 0.36, xerr=s, color='#1f4e8c', capsize=2, error_kw={'lw': 1})
    ax.text(a + s + 0.8, y[i] + 0.19, f'{a:.1f}', va='center', fontsize=8.5)
    if c in B.index:
        b = 100 * B.loc[c, 'acc_mean']; sb = 100 * B.loc[c, 'acc_sd']
        ax.barh(y[i] - 0.19, b, 0.36, xerr=sb, color='#c9a227', capsize=2, error_kw={'lw': 1})
        ax.text(b + sb + 0.8, y[i] - 0.19, f'{b:.1f}', va='center', fontsize=8.5)
ax.set_yticks(y); ax.set_yticklabels(lab); ax.set_xlim(0, 85); ax.set_xlabel('Test accuracy (%), mean ± SD over 5 seeds')
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color='#1f4e8c', label='Speaker-independent split (augmentation after split)'), Patch(color='#c9a227', label='Random split after augmentation (leaky)')], loc='upper center', bbox_to_anchor=(0.45, 1.13), ncol=1, frameon=False, fontsize=8.5); plt.tight_layout(); plt.savefig(f'{R}/figures/fig_ablation_leakage.png', dpi=250); plt.close()
cm = pd.read_csv(f'{R}/confusion_Combined_summedover5seeds.csv', index_col=0); n = cm.values / cm.values.sum(1, keepdims=True)
fig, ax = plt.subplots(figsize=(5.4, 4.6)); im = ax.imshow(n, cmap='Blues', vmin=0, vmax=1)
ax.set_xticks(range(7)); ax.set_yticks(range(7)); ax.set_xticklabels(cm.columns, rotation=40, ha='right'); ax.set_yticklabels(cm.index)
for i in range(7):
    for j in range(7): ax.text(j, i, f'{100 * n[i, j]:.0f}', ha='center', va='center', fontsize=8.5, color='white' if n[i, j] > 0.5 else '#222')
ax.set_xlabel('Predicted'); ax.set_ylabel('True'); plt.colorbar(im, fraction=0.046, label='Fraction of true class'); plt.tight_layout()
plt.savefig(f'{R}/figures/fig_confusion_speaker_independent.png', dpi=250); plt.close()
print('ok'); print(sm.round(4).to_string(index=False)); print('per-class recall %:', dict(zip(cm.index, (100 * np.diag(n)).round(1))))
