"""Step 2: speaker-independent speech experiments + leakage comparison + ablation + baselines.

Protocol A (speaker-independent, correct): per corpus, ~20% of speakers are held out for TEST (original, unaugmented clips only).
  Augmented copies are made only for TRAIN speakers. Repeated for 5 seeds (a different speaker split per seed).
Protocol B (leaky, for comparison): all original + augmented clips pooled, then a random stratified 80/20 split.
  Augmented copies of a test clip's recording can sit in training (the issue Reviewer 2 raised).
Configurations (classifier = MLP unless noted):
  hand, w2v, combined, combined+ReliefF(top-k)   |  baselines: SVM-RBF(hand), RandomForest(hand), LogReg(w2v)
ReliefF is implemented here (multi-class, k nearest hits / k nearest misses per class, class-prior weighted),
neighbours exclude the sampled clip's own augmented sibling.  It is ReliefF, not Iterative-RELIEF (I-RELIEF).
"""
import json, os, platform, sys, time
import numpy as np, pandas as pd, sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f'{ROOT}/results'
SEEDS = [0, 1, 2, 3, 4]
TEST_FRAC, TOPK, M_RELIEF, K_NEIGH = 0.20, 300, 600, 10
FEATS = os.environ.get('FEATS', f'{RES}/features.npz')
OUT = os.environ.get('OUT', RES)

D = np.load(FEATS, allow_pickle=True)
Xh, Xw, y, spk, cor, aug, oid = (D[k] for k in ['X_hand', 'X_w2v', 'y', 'speaker', 'corpus', 'is_aug', 'orig_idx'])
CLASSES = list(D['classes'])
Xc = np.concatenate([Xh, Xw], 1)
log = open(f'{OUT}/run_log.txt', 'a')
def P(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); log.write(s + '\n'); log.flush()

def relieff(X, y, oid, m, k, seed):
    """Multi-class ReliefF weights. X is min-max scaled to [0,1]."""
    rng = np.random.default_rng(seed); n, d = X.shape
    classes, counts = np.unique(y, return_counts=True); prior = dict(zip(classes, counts / n))
    W = np.zeros(d, np.float32)
    for i in rng.choice(n, size=min(m, n), replace=False):
        diff = np.abs(X - X[i])                        # n x d per-feature diff in [0,1]
        dist = diff.sum(1); dist[oid == oid[i]] = np.inf  # ignore itself and its augmented sibling
        for c in classes:
            idx = np.where(y == c)[0]; nn = idx[np.argsort(dist[idx])[:k]]
            if c == y[i]: W -= diff[nn].mean(0) / m
            else: W += (prior[c] / (1 - prior[y[i]])) * diff[nn].mean(0) / m
    return W

def split_speakers(seed):
    rng = np.random.default_rng(1000 + seed); test = []
    for c in sorted(set(cor)):
        sp = sorted(set(spk[cor == c])); nt = max(1, round(TEST_FRAC * len(sp)))
        test += list(rng.choice(sp, nt, replace=False))
    return set(test)

def fit_eval(name, Xtr, ytr, Xte, yte, seed, clf='mlp', relief_oid=None):
    sc = StandardScaler().fit(Xtr); A, B = sc.transform(Xtr), sc.transform(Xte); sel = None
    if '+ ReliefF' in name:
        lo, hi = Xtr.min(0), Xtr.max(0); S = (Xtr - lo) / np.maximum(hi - lo, 1e-9)
        w = relieff(S.astype(np.float32), ytr, relief_oid, M_RELIEF, K_NEIGH, seed)
        sel = np.argsort(-w)[:TOPK]; A, B = A[:, sel], B[:, sel]
    if clf == 'mlp': mdl = MLPClassifier((256,), early_stopping=True, max_iter=300, random_state=seed)
    elif clf == 'svm': mdl = SVC(kernel='rbf', C=10, random_state=seed)
    elif clf == 'rf': mdl = RandomForestClassifier(300, n_jobs=-1, random_state=seed)
    else: mdl = LogisticRegression(max_iter=2000, random_state=seed)
    mdl.fit(A, ytr); pr = mdl.predict(B)
    return dict(acc=accuracy_score(yte, pr), f1=f1_score(yte, pr, average='macro'), pred=pr, sel=sel)

CONFIGS = [  # (name, matrix, classifier)
    ('Handcrafted only (MLP)', Xh, 'mlp'), ('Wav2Vec 2.0 only (MLP)', Xw, 'mlp'),
    ('Combined (MLP)', Xc, 'mlp'), ('Combined + ReliefF (MLP)', Xc, 'mlp'),
    ('SVM-RBF on handcrafted [baseline]', Xh, 'svm'), ('RandomForest on handcrafted [baseline]', Xh, 'rf'),
    ('LogReg on Wav2Vec 2.0 [baseline]', Xw, 'lr')]

if __name__ == '__main__':
    t0 = time.time()
    json.dump(dict(python=sys.version, platform=platform.platform(), numpy=np.__version__, sklearn=sklearn.__version__,
                   seeds=SEEDS, test_frac=TEST_FRAC, topk=TOPK, relief_m=M_RELIEF, relief_k=K_NEIGH,
                   n_clips=int((aug == 0).sum()), features_file=FEATS), open(f'{OUT}/environment.json', 'w'), indent=2)
    rows, cms = [], {}
    for seed in SEEDS:
        test_spk = split_speakers(seed)
        te = np.isin(spk, list(test_spk)) & (aug == 0); tr = ~np.isin(spk, list(test_spk))  # train: orig + aug of TRAIN speakers only
        json.dump(dict(seed=seed, test_speakers=sorted(test_spk), n_train=int(tr.sum()), n_test=int(te.sum())),
                  open(f'{OUT}/split_seed{seed}.json', 'w'), indent=1)
        P(f'[seed {seed}] speaker-independent: train {tr.sum()} (incl. aug)  test {te.sum()} clips, {len(test_spk)} held-out speakers')
        for name, X, clf in CONFIGS:
            r = fit_eval(name, X[tr], y[tr], X[te], y[te], seed, clf, relief_oid=oid[tr])
            rows.append(dict(protocol='A speaker-independent', config=name, seed=seed, acc=r['acc'], macro_f1=r['f1'], n_test=int(te.sum())))
            cms.setdefault(name, np.zeros((7, 7), int)); cms[name] += confusion_matrix(y[te], r['pred'], labels=range(7))
            P(f'   {name:42s} acc {r["acc"]:.4f}  macroF1 {r["f1"]:.4f}   ({time.time() - t0:.0f}s)')
        # protocol B: augment first, then random split (leaky)
        itr, ite = train_test_split(np.arange(len(y)), test_size=0.2, stratify=y, random_state=seed)
        for name, X, clf in CONFIGS[:4]:
            r = fit_eval(name, X[itr], y[itr], X[ite], y[ite], seed, clf, relief_oid=oid[itr])
            rows.append(dict(protocol='B random split after augmentation (leaky)', config=name, seed=seed, acc=r['acc'], macro_f1=r['f1'], n_test=len(ite)))
            P(f'   [leaky B] {name:36s} acc {r["acc"]:.4f}')
        pd.DataFrame(rows).to_csv(f'{OUT}/per_seed_results.csv', index=False)
    df = pd.DataFrame(rows)
    sm = df.groupby(['protocol', 'config']).agg(acc_mean=('acc', 'mean'), acc_sd=('acc', 'std'), f1_mean=('macro_f1', 'mean'), f1_sd=('macro_f1', 'std')).reset_index()
    sm.to_csv(f'{OUT}/summary.csv', index=False); P('\n' + sm.round(4).to_string(index=False))
    for name, cm in cms.items():
        pd.DataFrame(cm, index=CLASSES, columns=CLASSES).to_csv(f'{OUT}/confusion_{name.split(" (")[0].replace(" ", "_").replace("+", "plus").replace("/", "")}_summedover5seeds.csv')
    P(f'done in {time.time() - t0:.0f}s')
