"""Facial step 2: single-backbone vs dual-backbone ablation, ReliefF, and classical baseline on FER-2013.

Protocol: standard FER-2013 split. Train on `train` (28,709). Model selection is NOT done on the test set:
  classifier early-stopping uses an internal 10% hold-out of train; reported numbers are on `privateTest` (3,589),
  and `publicTest` (3,589) is reported separately as the validation-style set.
Backbones are frozen ImageNet-pretrained ResNet-152 (2048-d) and EfficientNet-B7 (2560-d); they are NOT fine-tuned,
so this is not a re-run of the paper's fine-tuned dual-backbone model.
ReliefF (own implementation, as for speech): k=10 neighbours per class, class-prior weighting; computed on a random
8,000-image subset of the training set (m=400 sampled images, neighbours searched in the subset); top 300 features kept.
5 seeds (classifier initialisation + ReliefF sampling + subset). Backbone features are deterministic.
"""
import json, os, platform, sys, time
import numpy as np, pandas as pd, sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); RES = f'{ROOT}/results'
FEATS = os.environ.get('FEATS', f'{RES}/face_features.npz'); OUT = os.environ.get('OUT', RES)
SEEDS = [0, 1, 2, 3, 4]; TOPK, SUB, M, K = 300, 8000, 400, 10
D = np.load(FEATS, allow_pickle=True); CLASSES = list(D['classes'])
g = lambda s, k: D[f'{s}_{k}']
ytr, yva, yte = g('train', 'y'), g('publicTest', 'y'), g('privateTest', 'y')
log = open(f'{OUT}/face_run_log.txt', 'a')
def P(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); log.write(s + '\n'); log.flush()

def relieff(X, y, m, k, seed):
    rng = np.random.default_rng(seed); n, d = X.shape
    classes, counts = np.unique(y, return_counts=True); prior = dict(zip(classes, counts / n)); W = np.zeros(d, np.float32)
    for i in rng.choice(n, size=min(m, n), replace=False):
        diff = np.abs(X - X[i]); dist = diff.sum(1); dist[i] = np.inf
        for c in classes:
            idx = np.where(y == c)[0]; nn = idx[np.argsort(dist[idx])[:k]]
            W += (-1 if c == y[i] else prior[c] / (1 - prior[y[i]])) * diff[nn].mean(0) / m
    return W

def run(name, key, clf, seed):
    Xtr = np.concatenate([g('train', k) for k in key], 1); Xva = np.concatenate([g('publicTest', k) for k in key], 1); Xte = np.concatenate([g('privateTest', k) for k in key], 1)
    sc = StandardScaler().fit(Xtr); A, V, B = sc.transform(Xtr), sc.transform(Xva), sc.transform(Xte)
    if '+ ReliefF' in name:
        rng = np.random.default_rng(seed); sub = rng.choice(len(A), SUB, replace=False)
        S = Xtr[sub]; S = (S - S.min(0)) / np.maximum(S.max(0) - S.min(0), 1e-9)
        w = relieff(S.astype(np.float32), ytr[sub], M, K, seed); sel = np.argsort(-w)[:TOPK]; A, V, B = A[:, sel], V[:, sel], B[:, sel]
    if clf == 'mlp': mdl = MLPClassifier((256,), early_stopping=True, validation_fraction=0.1, max_iter=200, random_state=seed, alpha=1e-3)
    elif clf == 'svm': mdl = LinearSVC(C=0.01, random_state=seed, max_iter=5000)
    else: mdl = LogisticRegression(max_iter=500, random_state=seed)
    mdl.fit(A, ytr); ptr, pva, pte = mdl.predict(A), mdl.predict(V), mdl.predict(B)
    return dict(train=accuracy_score(ytr, ptr), val=accuracy_score(yva, pva), test=accuracy_score(yte, pte), f1=f1_score(yte, pte, average='macro'), pred=pte)

CONFIGS = [('EfficientNet-B7 only (MLP)', ['b7'], 'mlp'), ('ResNet-152 only (MLP)', ['r152'], 'mlp'),
           ('Dual backbone (MLP)', ['r152', 'b7'], 'mlp'), ('Dual backbone + ReliefF (MLP)', ['r152', 'b7'], 'mlp'),
           ('HOG + linear SVM [baseline]', ['hog'], 'svm'), ('Logistic regression, dual backbone [baseline]', ['r152', 'b7'], 'lr')]
if __name__ == '__main__':
    t0 = time.time(); rows, cms = [], {}
    json.dump(dict(python=sys.version, platform=platform.platform(), sklearn=sklearn.__version__, seeds=SEEDS, relief=dict(topk=TOPK, subset=SUB, m=M, k=K),
                   n_train=len(ytr), n_val=len(yva), n_test=len(yte)), open(f'{OUT}/face_environment.json', 'w'), indent=2)
    for seed in SEEDS:
        for name, key, clf in CONFIGS:
            if clf != 'mlp' and 'ReliefF' not in name and seed > 0 and clf in ('svm', 'lr'): continue  # deterministic-ish baselines: one run
            r = run(name, key, clf, seed)
            rows.append(dict(config=name, seed=seed, train_acc=r['train'], val_acc=r['val'], test_acc=r['test'], test_macro_f1=r['f1']))
            cms.setdefault(name, np.zeros((7, 7), int)); cms[name] += confusion_matrix(yte, r['pred'], labels=range(7))
            P(f'[seed {seed}] {name:48s} train {r["train"]:.4f}  val {r["val"]:.4f}  test {r["test"]:.4f}  F1 {r["f1"]:.4f}  ({time.time() - t0:.0f}s)')
        pd.DataFrame(rows).to_csv(f'{OUT}/face_per_seed_results.csv', index=False)
    df = pd.DataFrame(rows)
    sm = df.groupby('config').agg(n_runs=('seed', 'count'), train_mean=('train_acc', 'mean'), val_mean=('val_acc', 'mean'), val_sd=('val_acc', 'std'),
                                  test_mean=('test_acc', 'mean'), test_sd=('test_acc', 'std'), f1_mean=('test_macro_f1', 'mean'), f1_sd=('test_macro_f1', 'std')).reset_index()
    sm.to_csv(f'{OUT}/face_summary.csv', index=False); P('\n' + sm.round(4).to_string(index=False))
    for n, cm in cms.items(): pd.DataFrame(cm, index=CLASSES, columns=CLASSES).to_csv(f'{OUT}/face_confusion_{n.split(" (")[0].replace(" ", "_").replace("+", "plus").replace(",", "")}.csv')
    P(f'done in {time.time() - t0:.0f}s')
