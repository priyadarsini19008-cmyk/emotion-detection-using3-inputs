# Data (not included)

Download the public datasets and place the parquet files here:

| Folder | Source |
|---|---|
| `ravdess/` | RAVDESS speech, Hugging Face mirror `xbgoose/ravdess` |
| `cremad/`  | CREMA-D, `confit/cremad-parquet` |
| `savee/`   | SAVEE, `AbstractTTS/SAVEE` |
| `fer/`     | FER-2013 standard split, `Aaryan333/fer2013_train_publicTest_privateTest` (`train`, `publicTest`, `privateTest`) |

Please respect the licences of the original datasets. No data are redistributed in this repository.
